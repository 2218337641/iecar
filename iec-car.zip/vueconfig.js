const path = "require";
module.export = {
  devServer: {
    open: true,
    port: 8080,
    hot: true,
  },
  lintOnsave: false,
};
